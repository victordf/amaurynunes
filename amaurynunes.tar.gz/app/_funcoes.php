<?php
/**
 * Created by PhpStorm.
 * User: victor
 * Date: 10/09/16
 * Time: 16:03
 */

require_once "../vendor/phpmailer/phpmailer/PHPMailerAutoload.php";